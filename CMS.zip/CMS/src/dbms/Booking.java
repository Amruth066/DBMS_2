package dbms;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.util.Properties;

public class Booking
{
	private JPanel pn,pn1,pn2,pn3;
	private JFrame jframe;
	private JButton JB_insert,JB_modify,JB_view,JB_delete;
	private JLabel JL_Booking_id,JL_Toname,JL_Weight,JL_Toaddress,JL_Branch_id;
	private JTextField JTF_Booking_id,JTF_Toname,JTF_Weight,JTF_Toaddress,JTF_Branch_id;
	Connection con;
	ResultSet rs;
	Statement stmt;
	private JMenuItem insert2,update2,view2,delete2;
	private List BookingList;
	private Choice Branchid;//d_1
	
	public Booking(JPanel pn,JFrame jframe,JMenuItem insert2,JMenuItem update2,JMenuItem view2,JMenuItem delete2)
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectDatabase();
		
		this.jframe=jframe;
		this.insert2=insert2;
		this.update2=update2;
		this.view2=view2;
		this.delete2=delete2;
		
		JL_Booking_id=new JLabel("Booking_id:");
		JTF_Booking_id=new JTextField(10);
		JL_Toname=new JLabel("To Name:");
		JTF_Toname=new JTextField(10);
		JL_Weight=new JLabel("Weight:");
        JTF_Weight=new JTextField(10);
        JL_Toaddress=new JLabel("To Address:");
        JTF_Toaddress=new JTextField(10);
        JL_Branch_id=new JLabel("Branch_id:");
        JTF_Branch_id=new JTextField(10);

        this.pn=pn;
      
	}
	public void connectDatabase()
	{
		try 
		{
			Connection con=DriverManager.getConnection(  
			"jdbc:oracle:thin:@localhost:1521:xe","amruth","vasavi");  
			  
			stmt=con.createStatement(); 
			stmt.executeUpdate("commit");
			
		}
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
	}
	private void displaySQLErrors(SQLException e) 
	{
		JOptionPane.showMessageDialog(pn1,"\nSQLException: " + e.getMessage() + "\n"+"SQLState:     " + e.getSQLState() + "\n"+"VendorError:  " + e.getErrorCode() + "\n");
	}
	public void loadbranch()
	{
		try
		{
			Branchid=new Choice();
			Branchid.removeAll();
			rs=stmt.executeQuery("select * from branch");
			while(rs.next()) 
			{
				Branchid.add(rs.getString("Id"));
			}
		}
		catch(SQLException e) 
		{
			displaySQLErrors(e);
		}
	}
	public void loadbooking()
	{
		try
		{
			BookingList=new List();
			BookingList.removeAll();
			rs=stmt.executeQuery("select * from booking");
			while(rs.next()) 
			{
				BookingList.add(rs.getString("Bid"));
			}
		}
		catch(SQLException e) 
		{
			displaySQLErrors(e);
		}
	}
	public void buildGUI()
	{
		
		insert2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				JB_insert=new JButton("Insert");
				
				JTF_Booking_id.setText(null);
				JTF_Toname.setText(null);
				JTF_Weight.setText(null);
				JTF_Toaddress.setText(null);
				JTF_Branch_id.setText(null);
				
				loadbooking();
				
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				pn1=new JPanel();
				pn1.setLayout(new GridLayout(10,10));
				pn1.add(JL_Booking_id);
				pn1.add(JTF_Booking_id);
				pn1.add(JL_Toname);
				pn1.add(JTF_Toname);
				pn1.add(JL_Weight);
				pn1.add(JTF_Weight);
				pn1.add(JL_Toaddress);
				pn1.add(JTF_Toaddress);
				pn1.add(JL_Branch_id);
				pn1.add(JTF_Branch_id);
				
				
				pn3=new JPanel(new FlowLayout());
				pn3.add(JB_insert);
				pn1.setBounds(115,80,300,250);
				pn3.setBounds(200,350,75,35);
				 
				pn2=new JPanel(new FlowLayout());
				BookingList=new List(10);
				loadbooking();
				pn2.add(BookingList);
				pn2.setBounds(200,350,300,180);  
				
				pn.add(pn1);
				pn.add(pn3);
				pn.add(pn2);
				
				pn.setLayout(new BorderLayout());
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				JB_insert.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						try
						{
							String query= "INSERT INTO Booking VALUES("+ JTF_Booking_id.getText() + ",'"+JTF_Toname.getText() +"','"+JTF_Toaddress.getText()+"',"+JTF_Weight.getText() +","+JTF_Branch_id.getText()+")";
							int i = stmt.executeUpdate(query);
							JOptionPane.showMessageDialog(pn,"\nInserted "+i+" rows successfully");
							loadbooking();
							System.out.println("Done");
						}
						catch(SQLException e) 
						{
							displaySQLErrors(e);
						}
					}
				});	
			}
		});
		update2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				JB_modify=new JButton("Modify");
				
				JTF_Booking_id.setText(null);
				JTF_Toname.setText(null);
				JTF_Weight.setText(null);
				JTF_Toaddress.setText(null);
				JTF_Branch_id.setText(null);
				
				
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				pn1=new JPanel();
				pn1.setLayout(new GridLayout(10,10));
				
				pn1.add(JL_Booking_id);
				pn1.add(JTF_Booking_id);
				pn1.add(JL_Toname);
				pn1.add(JTF_Toname);
				pn1.add(JL_Weight);
				pn1.add(JTF_Weight);
				pn1.add(JL_Toaddress);
				pn1.add(JTF_Toaddress);
				pn1.add(JL_Branch_id);
				pn1.add(JTF_Branch_id);
				
				pn3=new JPanel(new FlowLayout());
				pn3.add(JB_modify);
				pn1.setBounds(115,80,300,250);
				pn3.setBounds(200,350,75,35);
				 
				pn2=new JPanel(new FlowLayout());
				BookingList=new List(10);
				loadbooking();
				pn2.add(BookingList);
				pn2.setBounds(200,350,300,180);  
				
				pn.add(pn1);
				pn.add(pn3);
				pn.add(pn2);
				
				pn.setLayout(new BorderLayout());
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				BookingList.addItemListener(new ItemListener() {
					public void itemStateChanged(ItemEvent ievt)
					{
						try 
						{
							rs=stmt.executeQuery("select * from Booking");
							while (rs.next()) 
							{
								if (rs.getString("Bid").equals(BookingList.getSelectedItem()))
								break;
							}
							if (!rs.isAfterLast()) 
							{
								JTF_Booking_id.setText(rs.getString("Bid"));
								JTF_Toname.setText(rs.getString("ToName"));
								JTF_Weight.setText(rs.getString("Weight"));
								JTF_Toaddress.setText(rs.getString("ToAddress"));
								JTF_Branch_id.setText(rs.getString("Id"));
								
							}
						} 
						catch (SQLException selectException) 
						{
							displaySQLErrors(selectException);
						}	
					}
				});	
				JB_modify.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						 try 
						 {
							int a=JOptionPane.showConfirmDialog(pn,"Are you sure want to update:");
							if(a==JOptionPane.YES_OPTION)
							{  
								String pack=JOptionPane.showInputDialog(pn,"Enter New  Name:");
								JTF_Toname.setText(pack);
								String query="update booking set ToName='"+pack+"' where Bid="+JTF_Booking_id.getText();
								int i=stmt.executeUpdate(query);
								JOptionPane.showMessageDialog(pn,"\nUpdated "+i+" rows succesfully");
								loadbooking();
							}
						 }
						catch(SQLException e)
						{
							displaySQLErrors(e);
						}
					}
				});
			}
		});
		delete2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				JB_delete=new JButton("Delete");

				JTF_Booking_id.setText(null);
				JTF_Toname.setText(null);
				JTF_Weight.setText(null);
				JTF_Toaddress.setText(null);
				JTF_Branch_id.setText(null);
				
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				pn1=new JPanel();
				pn1.setLayout(new GridLayout(10,10));
				pn1.add(JL_Booking_id);
				pn1.add(JTF_Booking_id);
				pn1.add(JL_Toname);
				pn1.add(JTF_Toname);
				pn1.add(JL_Weight);
				pn1.add(JTF_Weight);
				pn1.add(JL_Toaddress);
				pn1.add(JTF_Toaddress);
				pn1.add(JL_Branch_id);
				pn1.add(JTF_Branch_id);
				
				
				pn3=new JPanel(new FlowLayout());
				pn3.add(JB_delete);
				pn1.setBounds(115,80,300,250);
				pn3.setBounds(200,350,75,35);
				 
				pn2=new JPanel(new FlowLayout());
				BookingList=new List(10);
				loadbooking();
				pn2.add(BookingList);
				pn2.setBounds(200,350,300,200);  
				
				pn.add(pn1);
				pn.add(pn3);
				pn.add(pn2);
				
				pn.setLayout(new BorderLayout());
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				BookingList.addItemListener(new ItemListener() {
					public void itemStateChanged(ItemEvent ievt)
					{
						try 
						{
							rs=stmt.executeQuery("select * from Booking");
							while (rs.next()) 
							{
								if (rs.getString("Bid").equals(BookingList.getSelectedItem()))
								 break;
							}
							if (!rs.isAfterLast()) 
							{
								JTF_Booking_id.setText(rs.getString("Bid"));
								JTF_Toname.setText(rs.getString("ToName"));
								JTF_Weight.setText(rs.getString("weight"));
								JTF_Toaddress.setText(rs.getString("ToAddress"));
								JTF_Branch_id.setText(rs.getString("Id"));
								
							}
						} 
						catch (SQLException selectException) 
						{
							displaySQLErrors(selectException);
						}	
					}
				});	
				JB_delete.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						 try 
						 {
							int a=JOptionPane.showConfirmDialog(pn,"Are you sure want to Delete:");
							if(a==JOptionPane.YES_OPTION)
							{  
								//String query="DELETE FROM employee WHERE employee_id="+employeeList.getSelectedItem();
								String query="DELETE FROM Booking WHERE Bid="+JTF_Booking_id.getText();
								int i=stmt.executeUpdate(query);
								JOptionPane.showMessageDialog(pn,"\nDeleted "+i+" rows succesfully");
								loadbooking();
							}
						 }
						catch(SQLException e)
						{
							displaySQLErrors(e);
						}
					}
				});
			}
		});
 		view2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				JLabel view=new JLabel("Booking View");
				JB_view=new JButton("View");
				Font myFont = new Font("Serif",Font.BOLD,25);
			//	p2.setBackground(Color.cyan) ;
				view.setFont((myFont));
				
				pn1=new JPanel();
				pn2=new JPanel();
				pn1.add(view);
				pn2.add(JB_view);
				pn1.setBackground(Color.cyan) ;
				pn2.setBackground(Color.cyan) ;
				pn.add(pn1);
				pn.add(pn2);
				pn.setBounds(500,800,300,300);
				pn.setLayout(new FlowLayout());
			//	pn.setBackground(Color.cyan) ;
				
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				JB_view.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						JFrame jf=new JFrame("Booking Details");
						JTable jt;
						DefaultTableModel model = new DefaultTableModel(); 
				        jt = new JTable(model); 
				        model.addColumn("Booking_id");
				        model.addColumn("To name");
				        model.addColumn("Weight");
				        model.addColumn("To address");
				        model.addColumn("Branch Id");
					    try 
					    {		
							rs=stmt.executeQuery("select * from booking");
							while(rs.next())
							{
								model.addRow(new Object[]{rs.getString("Bid"), 
										rs.getString("ToName"),rs.getString("Weight"),rs.getString("ToAddress")
										,rs.getString("Id")});
							}
						}
						catch(SQLException e) 
					    {
							displaySQLErrors(e);
						}
						jt.setEnabled(false);
				        jt.setBounds(30, 40, 300, 300); 
				        JScrollPane jsp = new JScrollPane(jt); 
				        jf.add(jsp); 
				        jf.setSize(800, 400); 
				        jf.setVisible(true); 
					}
				});	
			}
		});	
	}
}