package dbms;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.util.Properties;

public class Schedule
{
	private JPanel pn,pn1,pn2,pn3;
	private JFrame jframe;
	private JButton JB_insert,JB_modify,JB_view,JB_delete;
	private JLabel JL_Schedule_id,JL_Booking_id,JL_Branch_id,JL_Staff_id;
	private JTextField JTF_Schedule_id,JTF_Booking_id,JTF_Branch_id,JTF_Staff_id;
	Connection con;
	ResultSet rs;
	Statement stmt;
	private JMenuItem insert4,update4,view4,delete4;
	private List ScheduleList;
	private Choice BookingId,BranchId,StaffId;
	
	public Schedule(JPanel pn,JFrame jframe,JMenuItem insert4,JMenuItem update4,JMenuItem view4,JMenuItem delete4)
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectDatabase();
		
		this.jframe=jframe;
		this.insert4=insert4;
		this.update4=update4;
		this.view4=view4;
		this.delete4=delete4;
		
		JL_Schedule_id=new JLabel("Schedule Id :");
		JTF_Schedule_id=new JTextField(10);
		JL_Booking_id=new JLabel("Booking Id:");
        JTF_Booking_id=new JTextField(10);
        JL_Branch_id=new JLabel("Branch Id:");
        JTF_Branch_id=new JTextField(10);
        JL_Staff_id=new JLabel("Staff Id:");
        JTF_Staff_id=new JTextField(10);

        this.pn=pn;
      
	}
	public void connectDatabase()
	{
		try 
		{
			Connection con=DriverManager.getConnection(  
			"jdbc:oracle:thin:@localhost:1521:xe","amruth","vasavi");  
			  
			stmt=con.createStatement(); 
			stmt.executeUpdate("commit");
			
		}
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
	}
	private void displaySQLErrors(SQLException e) 
	{
		JOptionPane.showMessageDialog(pn1,"\nSQLException: " + e.getMessage() + "\n"+"SQLState:     " + e.getSQLState() + "\n"+"VendorError:  " + e.getErrorCode() + "\n");
	}
	public void loadBooking()
	{
		try
		{
			BookingId=new Choice();
			BookingId.removeAll();
			rs=stmt.executeQuery("select * from Booking");
			while(rs.next()) 
			{
				BookingId.add(rs.getString("Bid"));
			}
		}
		catch(SQLException e) 
		{
			displaySQLErrors(e);
		}
	}
	public void loadbranch()
	{
		try
		{
			BranchId=new Choice();
			BranchId.removeAll();
			rs=stmt.executeQuery("select * from Branch");
			while(rs.next()) 
			{
				BranchId.add(rs.getString("Id"));
			}
		}
		catch(SQLException e) 
		{
			displaySQLErrors(e);
		}
	}
	public void loadstaff()
	{
		try
		{
			StaffId=new Choice();
			StaffId.removeAll();
			rs=stmt.executeQuery("select * from Staff");
			while(rs.next()) 
			{
				StaffId.add(rs.getString("Sid"));
			}
		}
		catch(SQLException e) 
		{
			displaySQLErrors(e);
		}
	}
	public void loadschedule()
	{ 
		try
		{
			ScheduleList=new List();
			ScheduleList.removeAll();
			rs=stmt.executeQuery("select * from Schedule");
			while(rs.next()) 
			{
				ScheduleList.add(rs.getString("Shid"));
			}
		}
		catch(SQLException e) 
		{
			displaySQLErrors(e);
		}   
	 } 
	public void buildGUI()
	{
		
		insert4.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				JB_insert=new JButton("Insert");
				
				JTF_Schedule_id.setText(null);
				JTF_Booking_id.setText(null);
				JTF_Branch_id.setText(null);
				JTF_Staff_id.setText(null);
				
				loadschedule();
				
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				pn1=new JPanel();
				pn1.setLayout(new GridLayout(10,10));
				pn1.add(JL_Schedule_id);
				pn1.add(JTF_Schedule_id);
				pn1.add(JL_Booking_id);
				pn1.add(JTF_Booking_id);
				pn1.add(JL_Branch_id);
				pn1.add(JTF_Branch_id);
				pn1.add(JL_Staff_id);
				pn1.add(JTF_Staff_id);
				
				
				pn3=new JPanel(new FlowLayout());
				pn3.add(JB_insert);
				pn1.setBounds(115,80,300,250);
				pn3.setBounds(200,350,75,35);
				 
				pn2=new JPanel(new FlowLayout());
				ScheduleList=new List(10);
				loadschedule();
				pn2.add(ScheduleList);
				pn2.setBounds(200,350,300,180);  
				
				pn.add(pn1);
				pn.add(pn3);
				pn.add(pn2);
				
				pn.setLayout(new BorderLayout());
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				JB_insert.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						try
						{
							String query= "INSERT INTO Schedule VALUES(" + JTF_Schedule_id.getText() + ","+JTF_Booking_id.getText()+"," +JTF_Staff_id.getText()+","+JTF_Branch_id.getText()+")";
							int i = stmt.executeUpdate(query);
							JOptionPane.showMessageDialog(pn,"\nInserted "+i+" rows successfully");
							loadschedule();
							System.out.println("Done");
						}
						catch(SQLException e) 
						{
							displaySQLErrors(e);
						}
					}
				});	
			}
		});
	/*	update4.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				JB_modify=new JButton("Modify");
				
				JTF_Schedule_id.setText(null);
				JTF_Booking_id.setText(null);
				JTF_Branch_id.setText(null);
				JTF_Staff_id.setText(null);
				
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				pn1=new JPanel();
				pn1.setLayout(new GridLayout(10,10));
				pn1.add(JL_Schedule_id);
				pn1.add(JTF_Schedule_id);
				pn1.add(JL_Booking_id);
				pn1.add(JTF_Booking_id);
				pn1.add(JL_Branch_id);
				pn1.add(JTF_Branch_id);
				pn1.add(JL_Staff_id);
				pn1.add(JTF_Staff_id);
				
				pn3=new JPanel(new FlowLayout());
				pn3.add(JB_modify);
				pn1.setBounds(115,80,300,250);
				pn3.setBounds(200,350,75,35);
				 
				pn2=new JPanel(new FlowLayout());
				ScheduleList=new List(10);
				loadschedule();
				pn2.add(ScheduleList);
				pn2.setBounds(200,350,300,180);  
				
				pn.add(pn1);
				pn.add(pn3);
				pn.add(pn2);
				
				pn.setLayout(new BorderLayout());
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				ScheduleList.addItemListener(new ItemListener() {
					public void itemStateChanged(ItemEvent ievt)
					{
						try 
						{
							rs=stmt.executeQuery("select * from Schedule");
							while (rs.next()) 
							{
								if (rs.getString("Schedule_id").equals(ScheduleList.getSelectedItem()))
								break;
							}
							if (!rs.isAfterLast()) 
							{
								JTF_Schedule_id.setText(rs.getString("Shid"));
								JTF_Booking_id.setText(rs.getString("Bid"));
								JTF_Branch_id.setText(rs.getString("Id"));
								JTF_Staff_id.setText(rs.getString("Sid"));
								
							}
						} 
						catch (SQLException selectException) 
						{
							displaySQLErrors(selectException);
						}	
					}
				});	
				JB_modify.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						 try 
						 {
							int a=JOptionPane.showConfirmDialog(pn,"Are you sure want to update:");
							if(a==JOptionPane.YES_OPTION)
							{  
								String pack=JOptionPane.showInputDialog(pn,"Enter New :");
								JTF_Schedule_id.setText(pack);
								String query="update Schedule set insurance_type='"+pack+"' where insurance_num="+JTF_insurance_num.getText();
								int i=stmt.executeUpdate(query);
								JOptionPane.showMessageDialog(pn,"\nUpdated "+i+" rows succesfully");
								loadinsurance();
							}
						 }
						catch(SQLException e)
						{
							displaySQLErrors(e);
						}
					}
				});
			}
		}); */
		delete4.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				JB_delete=new JButton("Delete");
				
				JTF_Schedule_id.setText(null);
				JTF_Booking_id.setText(null);
				JTF_Branch_id.setText(null);
				JTF_Staff_id.setText(null);
				
				
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				pn1=new JPanel();
				pn1.setLayout(new GridLayout(10,10));
				pn1.add(JL_Schedule_id);
				pn1.add(JTF_Schedule_id);
				pn1.add(JL_Booking_id);
				pn1.add(JTF_Booking_id);
				pn1.add(JL_Branch_id);
				pn1.add(JTF_Branch_id);
				pn1.add(JL_Staff_id);
				pn1.add(JTF_Staff_id);
				
				
				pn3=new JPanel(new FlowLayout());
				pn3.add(JB_delete);
				pn1.setBounds(115,80,300,250);
				pn3.setBounds(200,350,75,35);
				 
				pn2=new JPanel(new FlowLayout());
				ScheduleList=new List(10);
				loadschedule();
				pn2.add(ScheduleList);
				pn2.setBounds(200,350,300,200);  
				
				pn.add(pn1);
				pn.add(pn3);
				pn.add(pn2);
				
				pn.setLayout(new BorderLayout());
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				ScheduleList.addItemListener(new ItemListener() {
					public void itemStateChanged(ItemEvent ievt)
					{
						try 
						{
							rs=stmt.executeQuery("select * from Schedule");
							while (rs.next()) 
							{
								if (rs.getString("Shid").equals(ScheduleList.getSelectedItem()))
								 break;
							}
							if (!rs.isAfterLast()) 
							{
								
								JTF_Schedule_id.setText(rs.getString("Shid"));
								JTF_Booking_id.setText(rs.getString("Bid"));
								JTF_Branch_id.setText(rs.getString("Id"));
								JTF_Staff_id.setText(rs.getString("Sid"));
								
								
								
							}
						} 
						catch (SQLException selectException) 
						{
							displaySQLErrors(selectException);
						}	
					}
				});	
				JB_delete.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						 try 
						 {
							int a=JOptionPane.showConfirmDialog(pn,"Are you sure want to Delete:");
							if(a==JOptionPane.YES_OPTION)
							{  
								//String query="DELETE FROM insurance WHERE insurance_num="+insuranceList.getSelectedItem();
								String query="DELETE FROM Schedule WHERE Shid="+JTF_Schedule_id.getText();
								int i=stmt.executeUpdate(query);
								JOptionPane.showMessageDialog(pn,"\nDeleted "+i+" rows succesfully");
								loadschedule();
							}
						 }
						catch(SQLException e)
						{
							displaySQLErrors(e);
						}
					}
				});
			}
		});
 		view4.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				JLabel view=new JLabel("Schedule View");
				JB_view=new JButton("View");
				Font myFont = new Font("Serif",Font.BOLD,25);
				view.setFont((myFont));
				
				pn1=new JPanel();
				pn2=new JPanel();
				pn1.add(view);
				pn2.add(JB_view);
				pn1.setBackground(Color.cyan) ;
				pn2.setBackground(Color.cyan) ;
				pn.add(pn1);
				pn.add(pn2);
				pn.setBounds(500,800,300,300);
				pn.setLayout(new FlowLayout());
				
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				JB_view.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						JFrame jf=new JFrame("Schedule Details");
						JTable jt;
						DefaultTableModel model = new DefaultTableModel(); 
				        jt = new JTable(model); 
				        model.addColumn("Schedule Id");
				        model.addColumn("Booking Id");
				        model.addColumn("Branch Id");
				        model.addColumn("Staff Id");
					    try 
					    {		
							rs=stmt.executeQuery("select * from Schedule");
							while(rs.next())
							{
								model.addRow(new Object[]{rs.getString("Shid"), 
										rs.getString("Shid"),rs.getString("Bid"),rs.getString("id"),rs.getString("sid")});
							}
						}
						catch(SQLException e) 
					    {
							displaySQLErrors(e);
						}
						jt.setEnabled(false);
				        jt.setBounds(30, 40, 300, 300); 
				        JScrollPane jsp = new JScrollPane(jt); 
				        jf.add(jsp); 
				        jf.setSize(800, 400); 
				        jf.setVisible(true); 
					}
				 });	
			   }
		     });
	        }
   }
