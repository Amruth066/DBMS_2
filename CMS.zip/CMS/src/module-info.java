module CMS {
	requires java.desktop;
	requires java.sql;
}